<?php
// Establish database connection
// $servername = "85.10.192.25";
$servername = "localhost";
$username = "sunwayst_sunwayadmin";
$password = "sunway@123";
$dbname = "spin_game";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if database exists, if not, create it
$date = date("Y_m_d");
$dbname = "spin_game_" . $date;

$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

$conn->close();

// Connect to the newly created database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$number = $_POST['number'];
$email = $_POST['email'];

// Insert data into database
$sql = "INSERT INTO participants (name, number, email) VALUES ('$name', '$number', '$email')";
if ($conn->query($sql) === TRUE) {
    // Redirect to success page
    header("Location: main.html");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
